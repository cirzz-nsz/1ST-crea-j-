<?php
// proteger_sesion.php
// Poné esto AL INICIO de teclado.php (y de cualquier página que
// requiera estar logueado), antes de cualquier HTML.
session_start();

if (!isset($_SESSION["usuario_id"])) {
    header("Location: Login.php");
    exit;
}
?>



<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sin Límites</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="headerfooter.css">
<link rel="stylesheet" href="newteclado.css">
<link rel="stylesheet" href="auth.css">
<link rel="stylesheet" href="comentarios.css">
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=JetBrains+Mono:wght@400;600;700&display=swap" rel="stylesheet">

</head>
<body>

  <!-- fondo de estrellitas animadas, estrellas.js las genera dentro de este div -->
  <div class="estrellas" id="estrellas"></div>

  <!-- HEADER: logo + menu de navegacion, igual en todas las paginas del sitio -->
  <header>
    <div class="logo">
      <img src="Logo Crea J Sin Limites amarillosinfondo.png" alt="Logo">
      <div>
        <h1>Sin Límites</h1>
      </div>
    </div>
    <button class="menu-toggle" id="menuToggle" aria-label="Abrir menú">
      <i class="fas fa-bars"></i>
    </button>
    <nav>
      <a href="Inicio.html">
        <i class="fas fa-house"></i>
        Inicio
      </a>
      <a href="descubrebraile.html">
        <i class="fas fa-eye"></i>
        Descubre el Braille
      </a>
      <a href="Mas info.html">
        <i class="fas fa-book-open"></i>
        Historia
      </a>
      <a href="proyecto.html">
        <i class="fas fa-diagram-project"></i>
        Sobre nosotros
      </a>
      <a href="contactos.html">
        <i class="fas fa-envelope"></i>
        Contacto
      </a>
      <!-- class="activo" marca en cual pagina estamos parados (le da el fondo azul) -->
      <a href="teclado.php" class="activo">
        <i class="fas fa-keyboard"></i>
        Teclado
      </a>
    </nav>
    <!-- auth.js llena esto con el saludo + botón de cerrar sesión -->
    <div id="authHeaderSlot"></div>
  </header>

  <!-- TECLADO: teclado.js arma cada tecla dentro de #keyboard en tiempo real,
       acá en el HTML solo va la caja vacía -->
  <div class="wrap">
    <div class="stage">
      <div id="kbcontainer" class="mode-wave">
        <!-- canvas donde se dibujan las particulas al presionar una tecla -->
        <canvas id="particles"></canvas>
        <!-- teclado.js llena esto con las filas y teclas -->
        <div id="keyboard"></div>
      </div>
    </div>
  </div>

  <!-- LOG: va mostrando cada tecla que se presiona, lo actualiza teclado.js -->
  <div class="logbar" id="logbar">
    <span class="dim"></span>
  </div>

  <!-- PANEL DE LA FRASE: donde se arma el texto en braille y los controles para editarlo/leerlo -->
  <div class="phrase-panel">
    <h2>Frase en Braille</h2>
    <p class="sub">Escribe con tu teclado físico para formar la frase. Usa los botones para editar o para escucharla completa.</p>

    <!-- teclado.js va escribiendo el texto acá adentro -->
    <div class="phrase-out" id="phraseOut">&nbsp;</div>

    <div class="phrase-btns">
      <button class="btn" id="addBtn">+ Agregar espacio</button>
      <button class="btn secondary" id="delBtn">Borrar</button>
      <button class="btn secondary" id="clrBtn">Limpiar</button>
      <!-- <button class="btn read" id="readBtn">Leer frase</button> -->
      <button class="btn contrast" id="contrastBtn">Alto contraste</button>
    </div>

    <!-- checkboxes de configuracion -->
    <div class="phrase-toggles">
      <label class="chk">
        <input type="checkbox" id="autoVoiceChk" checked>
        Leer cada letra al escribirla
      </label>
      <label class="chk">
        <input type="checkbox" id="showLettersChk">
        Mostrar letra debajo del símbolo
      </label>
    </div>
  </div>

  <!-- ZONA DE COMENTARIOS: requiere estar con una cuenta para poder comentar -->
  <div class="comentarios-panel">
    <h2>Comentarios</h2>
    <p class="sub">Contanos qué te pareció el teclado. Necesitás una cuenta para comentar.</p>

    <div class="comentarios-bloqueado" id="comentariosBloqueado" style="display:none;">
      <i class="fas fa-lock"></i>
      <span>Tenés que <a href="Login.php">iniciar sesión</a> o <a href="registro.php">crear una cuenta</a> para dejar un comentario.</span>
    </div>

    <form class="form-comentario" id="formComentario" style="display:none;">
      <textarea id="textoComentario" placeholder="Escribí tu comentario..." required></textarea>
      <button type="submit"><i class="fas fa-paper-plane"></i> Comentar</button>
    </form>
    <p class="preview-braille" id="previewBraille"></p>

    <label class="comentarios-toggle">
      <input type="checkbox" id="toggleTextoPlano">
      Mostrar también el texto en tinta debajo de cada comentario
    </label>

    <div class="lista-comentarios" id="listaComentarios"></div>
  </div>

  <!-- FOOTER: igual en todas las paginas (Navegación / Recursos / Síguenos + copyright) -->
  <footer class="footer">
    <div class="contenedor">
      <div class="footer-row">
        <div class="footer-links">
          <h4>Navegación</h4>
          <ul>
            <li><a href="Inicio.html">Inicio</a></li>
            <li><a href="descubrebraile.html">Descubre el Braille</a></li>
            <li><a href="Mas info.html">Historia</a></li>
            <li><a href="proyecto.html">Proyecto</a></li>
            <li><a href="contactos.html">Contacto</a></li>
          </ul>
        </div>
        <div class="footer-links">
          <h4>Recursos</h4>
          <ul>
            <li><a href="#">¿Qué es el Braille?</a></li>
            <li><a href="#">Aprender Braille</a></li>
            <li><a href="#">Alfabeto Braille</a></li>
            <li><a href="#">Accesibilidad</a></li>
          </ul>
        </div>
        <div class="footer-links">
          <h4>Síguenos</h4>
          <div class="social-link">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
            <a href="#"><i class="fab fa-github"></i></a>
          </div>
        </div>
      </div>
      <div class="footer-copy">
        © 2026 Sin Límites
      </div>
    </div>
  </footer>

  <!-- teclado.js arma el teclado y maneja toda la logica de escritura/voz/sonido.
estrellas.js solo genera las estrellitas del fondo -->
  <!-- le pasamos la sesión de PHP a JS, así auth.js sabe si estás logueado -->
  <script>
    window.SinLimitesUsuario = <?php
      echo isset($_SESSION["usuario_id"])
        ? json_encode(["id" => $_SESSION["usuario_id"], "nombre" => $_SESSION["usuario_nombre"]])
        : "null";
    ?>;
  </script>

  <script src="auth.js"></script>
  <script src="teclado.js"></script>
  <script src="estrellas.js"></script>
  <script src="menu.js"></script>

  <!-- comentarios.js maneja la zona de comentarios (requiere sesión) -->
  <script src="comentario.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", function(){
      try{
        pintarUsuarioHeader();
      }catch(err){
        console.error("Error en pintarUsuarioHeader:", err);
      }

      try{
        iniciarZonaComentarios("teclado");
      }catch(err){
        console.error("Error en iniciarZonaComentarios:", err);
      }
    });
  </script>
</body>
</html>